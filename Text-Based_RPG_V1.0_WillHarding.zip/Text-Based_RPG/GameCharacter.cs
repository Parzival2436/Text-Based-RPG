﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Text_Based_RPG
{
    class GameCharacter
    {
        protected int posX;
        protected int posY;
        public int life;
        public string avatar;
        protected bool pathBlocked;
    }
}
